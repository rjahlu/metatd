/**
 * Created by alicia.sykes on 17/07/2015.
 */
alert(null);
stupid();
function stupid(){
    return null;
}